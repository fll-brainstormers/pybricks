
from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Side, Color, Button

def demo(drive_base, module_motor):
    additional_motor = Motor(Port.D)
    drive_base.settings(turn_rate=80)
    drive_base.turn(36000, wait=False)
    module_motor.run_angle(200, 36000, wait=False)
    for i in range(0, 100):
        additional_motor.run_until_stalled(-100)
        additional_motor.run_until_stalled(100)

