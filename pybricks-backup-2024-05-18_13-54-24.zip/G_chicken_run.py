from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Side, Color, Button
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub
from pybricks.tools import wait

def chicken_run(drive_base, module_motor):
    additional_motor = Motor(Port.D)
    
    drive_base.settings(195,733,126,571) #default
    drive_base.use_gyro(True)
    
    module_motor.run_time(-200, 1000, wait=False)
    drive_base.curve(350, 50)
    drive_base.straight(70)
    module_motor.run_time(150, 1500)
    drive_base.straight(500, wait=False)
    drive_base.settings(900)
    drive_base.straight(200)
    drive_base.curve(300, 45, wait=False)
    additional_motor.run_time(-1000, 3000)
    drive_base.use_gyro(False)
    drive_base.straight(-100)
    drive_base.curve(-400, 110, wait=False)
    wait(4000)
    additional_motor.close()

if __name__ == '__main__':
    hub = PrimeHub()
    print("Battery:", hub.battery.voltage(), 'mV')
    hub.display.orientation(up=Side.RIGHT)

    left_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
    right_motor = Motor(Port.E)
    module_motor = Motor(Port.C)

    drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=147)

    chicken_run(drive_base,module_motor)