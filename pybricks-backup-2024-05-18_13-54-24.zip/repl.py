from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Side, Color, Button
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub
from pybricks.tools import wait

hub = PrimeHub()
hub.display.orientation(up=Side.RIGHT)


# lignes à copier coller pour le pas à pas(bouton >>>)
hub.display.orientation(up=Side.RIGHT)

left_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
right_motor = Motor(Port.E)
module_motor = Motor(Port.C)
additional_motor = Motor(Port.D)


drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=147)
drive_base.use_gyro(True)

print("Battery:", hub.battery.voltage(), 'mV')

additional_motor.run_until_stalled(100)
wait(1000)
additional_motor.run_angle(150,-160)

'''
drive_base.straight(320)
drive_base.curve(400,-90)

drive_base.straight(225)
drive_base.turn(90)

drive_base.straight(-100)
'''
'''
for i in range(5):
    drive_base.straight(200)
    drive_base.turn(180)
    drive_base.straight(200)
    drive_base.turn(180)
'''