from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Side, Color, Button
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub
from pybricks.tools import wait

from B_run_1 import run_1
from C_run_sound_mixer import run_sound_mixer
from D_Run_3 import run_3
from E_run_4 import run_4
from F_Chicken_run import chicken_run
from G_run_light_and_sound import run_light_and_sound
from H_run_7 import run_7
from demo import demo


hub = PrimeHub()
hub.display.orientation(up=Side.RIGHT)

print("Battery:", hub.battery.voltage(), 'mV')

left_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
right_motor = Motor(Port.E)
module_motor = Motor(Port.C)

drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=147)
drive_base.use_gyro(True)

additional_motor = Motor(Port.D)

module_motor.run_angle(200, 500)
drive_base.curve(200,-45)
drive_base.straight(100)
module_motor.run_angle(-100000, 400)
drive_base.straight(400)
additional_motor.run_angle(-100000, 2000)
drive_base.settings(900)
drive_base.straight(-800)

