from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Side, Color, Button
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub
from pybricks.tools import wait

"""
fait le dragon et place un bonhomme orange
"""
def run_dragon(drive_base, module_motor):
    drive_base.use_gyro(False)
    drive_base.settings(195,733,126,571)

    drive_base.settings(400)
    drive_base.straight(400)
    drive_base.straight(-400, wait=False)
    wait(1000)

if __name__ == '__main__':
    hub = PrimeHub()
    hub.display.orientation(up=Side.RIGHT)

    left_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
    right_motor = Motor(Port.E)
    module_motor = Motor(Port.C)
    
    drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=147)
    print("Battery:", hub.battery.voltage(), 'mV')
    run_dragon(drive_base, module_motor)   

