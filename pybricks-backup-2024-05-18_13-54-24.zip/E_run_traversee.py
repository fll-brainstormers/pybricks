from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Side, Color, Button
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub
from pybricks.tools import wait

# run camera + levier de la caméra roulante + traversée
def run_traversee(drive_base, module_motor):
    drive_base.use_gyro(True)
    drive_base.settings(195,350,126,571)
    module_motor.run_until_stalled(400)
    drive_base.settings(turn_rate=350)
    drive_base.curve(100, 90)
    drive_base.settings(turn_rate=733)
    drive_base.straight(350)
    
    module_motor.run_time(-400, 2000)
    drive_base.straight(-140)
    
    drive_base.turn(-30)
    drive_base.straight(50)
    drive_base.turn(5)
    module_motor.run_until_stalled(100)
        
    drive_base.turn(-65)
    drive_base.curve(300,90)
    drive_base.turn(25)
    drive_base.settings(400)
    drive_base.use_gyro(False)
    drive_base.straight(1200, wait=False)
    wait(10000)


if __name__ == '__main__':
    hub = PrimeHub()
    hub.display.orientation(up=Side.RIGHT)

    left_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
    right_motor = Motor(Port.E)
    module_motor = Motor(Port.C)
    

    drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=147)
    run_traversee(drive_base, module_motor)   

