from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Side, Color, Button
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub
from pybricks.tools import wait

# run rails + scientifique clap + bonhomme orange
def run_rails(drive_base, module_motor):
    drive_base.use_gyro(False)
    drive_base.settings(195,733,126,571) #default
    drive_base.settings(straight_speed=900, straight_acceleration=2000)
    drive_base.straight(450)
    drive_base.straight(-450, wait=False)
    wait(2000)
    

if __name__ == '__main__':
    hub = PrimeHub()
    hub.display.orientation(up=Side.RIGHT)

    left_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
    right_motor = Motor(Port.E)
    module_motor = Motor(Port.C)
    
    drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=147)
    drive_base.use_gyro(True)
    run_rails(drive_base, module_motor)