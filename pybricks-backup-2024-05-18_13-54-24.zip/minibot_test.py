from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Side, Color, Button
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub
from pybricks.tools import wait


hub = PrimeHub()
hub.display.orientation(up=Side.RIGHT)

print("Battery:", hub.battery.voltage(), 'mV')

left_motor = Motor(Port.F, Direction.COUNTERCLOCKWISE)
right_motor = Motor(Port.B)
module_motor = Motor(Port.D)

drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=120)
drive_base.use_gyro(True)

module_motor.run_time(200, 1500)
drive_base.settings(350)
drive_base.straight(10)
drive_base.curve(848,90)
drive_base.straight(100)
drive_base.turn(180)
drive_base.straight(20)
module_motor.run_time(-200, 2000)
drive_base.straight(-30)