from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Side, Color, Button
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub
from pybricks.tools import wait

def run_sound_mixer(drive_base, module_motor): 
    drive_base.use_gyro(False)
    drive_base.settings(200,733,126,571)
    module_motor.run_time(500, 700, wait=False)
    drive_base.straight(560)
    module_motor.run_time(-900, 700, wait=False)
    wait(1000)
    drive_base.settings(straight_speed=100)
    drive_base.straight(-100)
    drive_base.settings(straight_speed=500)
    drive_base.straight(-450, wait=False)
    wait(3000)

if __name__ == '__main__':
    hub = PrimeHub()
    hub.display.orientation(up=Side.RIGHT)

    left_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
    right_motor = Motor(Port.E)
    module_motor = Motor(Port.C)

    drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=147)
    run_sound_mixer(drive_base, module_motor)
