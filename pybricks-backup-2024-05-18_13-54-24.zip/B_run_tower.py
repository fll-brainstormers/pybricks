from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Side, Color, Button
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub
from pybricks.tools import wait

"""
run où on fait le musée, l'hélico, les écrans violets, le manège + scientifique
"""

def run_tower(drive_base, module_motor):
    drive_base.use_gyro(True)
    drive_base.settings(195,350,126,571)
    additional_motor = Motor(Port.D)
    additional_motor.run_until_stalled(100)

    # allée vers le musée
    drive_base.curve(-470, -47)
    drive_base.straight(-150)
    drive_base.curve(-90, 55)
    drive_base.straight(-600)
    
    drive_base.turn(-45)
    drive_base.turn(45)

    # allée vers la tour
    drive_base.turn(20)
    drive_base.straight(250)
    drive_base.turn(-80)
    drive_base.straight(20)
    module_motor.run_angle(900,2000)
    
    # allée vers les screens
    drive_base.straight(-35)
    drive_base.turn(28)
    drive_base.settings(300)
    drive_base.straight(-400, wait=False)
    wait(3000)
    drive_base.straight(150)
    drive_base.turn(100)

    additional_motor.run_angle(150,-160, wait=False)
    drive_base.straight(360)
    additional_motor.run_angle(150, 90)
    drive_base.turn(10)

    drive_base.straight(60)
    drive_base.straight(-100)
    drive_base.straight(100)
    drive_base.straight(-40)

    drive_base.turn(-75)
    drive_base.settings(600)
    drive_base.use_gyro(False)
    drive_base.straight(650, wait=False)
    wait(4000)
    additional_motor.close()


if __name__ == '__main__':
    hub = PrimeHub()
    hub.display.orientation(up=Side.RIGHT)

    left_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
    right_motor = Motor(Port.E)
    module_motor = Motor(Port.C)

    drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=147)
    drive_base.use_gyro(True)
    run_tower(drive_base, module_motor)



