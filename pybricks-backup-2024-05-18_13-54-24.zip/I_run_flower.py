from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Side, Color, Button
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub
from pybricks.tools import wait

# run des poses de personnage + fleur
def run_flower(drive_base, module_motor):
    additional_motor = Motor(Port.D)    
    drive_base.settings(195,733,126,571)
    drive_base.use_gyro(True)

    drive_base.settings(200)
    drive_base.straight(320)
    drive_base.curve(400, -90)
    drive_base.straight(225)
    drive_base.turn(90)
    drive_base.straight(-100)
    drive_base.turn(45)
    drive_base.settings(100)
    drive_base.turn(-135)
    drive_base.settings(200)
    drive_base.straight(420)
    drive_base.turn(45)
    drive_base.straight(160)
    additional_motor.run_angle(100, -90)
    drive_base.straight(-110)
    drive_base.turn(-45)
    drive_base.straight(300)
    drive_base.turn(-30)

    additional_motor.close()

if __name__ == '__main__':
    hub = PrimeHub()
    hub.display.orientation(up=Side.RIGHT)

    left_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
    right_motor = Motor(Port.E)
    module_motor = Motor(Port.C)

    drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=147)
    drive_base.use_gyro(True)
    run_flower(drive_base, module_motor)