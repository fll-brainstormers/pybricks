from pybricks.pupdevices import Motor
from pybricks.parameters import Port, Direction, Side, Color, Button
from pybricks.robotics import DriveBase
from pybricks.hubs import PrimeHub

def run_light_and_sound(drive_base, module_motor):
    additional_motor = Motor(Port.D)

    drive_base.use_gyro(True)
    drive_base.settings(195,733,126,571)
    drive_base.curve(400, 25)
    drive_base.curve(400, -45)

    drive_base.straight(300)
    
    drive_base.straight(100, wait=False)
    drive_base.use_gyro(False)
    additional_motor.run_time(1000, 4000)
    drive_base.settings(400)
    drive_base.straight(-700)
    additional_motor.close()

if __name__ == '__main__':
    hub = PrimeHub()
    hub.display.orientation(up=Side.RIGHT)

    left_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
    right_motor = Motor(Port.E)
    module_motor = Motor(Port.C)

    drive_base = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=147)
    drive_base.use_gyro(True)
    run_light_and_sounds(drive_base, module_motor)
